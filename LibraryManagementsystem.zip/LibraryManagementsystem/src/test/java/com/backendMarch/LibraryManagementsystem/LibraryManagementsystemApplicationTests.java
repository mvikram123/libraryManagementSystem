package com.backendMarch.LibraryManagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
