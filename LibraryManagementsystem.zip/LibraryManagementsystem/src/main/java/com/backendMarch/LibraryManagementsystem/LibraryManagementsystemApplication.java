package com.backendMarch.LibraryManagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagementsystemApplication.class, args);
	}

}
